from setuptools import setup

setup(
    name="typesense-stubs",
    version="0.1",
    packages=["typesense-stubs"],
)
